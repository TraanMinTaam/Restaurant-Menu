/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import MODAL.clssDoUong;
import MODAL.clssMonAn;
import MODAL.clssNhanVien;

import java.io.FileOutputStream;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author ADMIN
 */
public class frmThucDon extends javax.swing.JFrame {

    /**
     * Creates new form frmMonAn
     */
    public frmThucDon() {
        initComponents();
        HienThiDSMonAn();
        HienThiDSDoUong();
        HienThiDSThongKe();
        HienThiNhanVien() ;
        TableDesign() ;
    }
    private void TableDesign()
    {
        //Sua bang mon an
       tblMonAn.getTableHeader().setOpaque(false) ;
       tblMonAn.getTableHeader().setBackground(java.awt.Color.darkGray);
       tblMonAn.getTableHeader().setFont(new java.awt.Font("Segoe UI Semilight",java.awt.Font.BOLD,16)) ;
       //Sua bang do uong
        tbThongKe.getTableHeader().setOpaque(false) ;
       tbThongKe.getTableHeader().setBackground(java.awt.Color.red);
       tbThongKe.getTableHeader().setFont(new java.awt.Font("Segoe UI Semilight",java.awt.Font.BOLD,16)) ;
       //Sua bang hoa don
       tbNhanVien.getTableHeader().setOpaque(false) ;
      tbNhanVien.getTableHeader().setBackground(java.awt.Color.red);
       tbNhanVien.getTableHeader().setFont(new java.awt.Font("Segoe UI Semilight",java.awt.Font.BOLD,16)) ;
    }
    
    public void HienThiDSMonAn(){
        Vector<clssMonAn> ds = new Vector<clssMonAn>();
        
        int ketqua = DAO.tbMonAn.LayDSMonAn(ds);
        if(ketqua == -1){
            JOptionPane.showMessageDialog(this, "Loi ket noi sql");
            return;
        }
        else if(ketqua == -2){
            JOptionPane.showMessageDialog(this, "Loi sql");
            return;
        }
        else{
            DefaultTableModel dtm = (DefaultTableModel)this.tblMonAn.getModel();
            dtm.setRowCount(0);
            for(clssMonAn dss : ds)
                dtm.addRow(new Object[] {dss.getSTT(), dss.getTenMonAn(), dss.getDonGia()});
        }
    }
   public void HienThiNhanVien() {
    Vector<clssNhanVien> ds = new Vector<clssNhanVien>();
    
    int ketqua = DAO.tbNhanVien.LayDSNhanVien(ds) ;
    if(ketqua == -1){
        JOptionPane.showMessageDialog(this, "Lỗi kết nối SQL");
        return;
    }
    else if(ketqua == -2){
        JOptionPane.showMessageDialog(this, "Lỗi SQL");
        return;
    }
    else {
        DefaultTableModel dtm = (DefaultTableModel)this.tbNhanVien.getModel();
        dtm.setRowCount(0);
        for(clssNhanVien dss : ds)
            dtm.addRow(new Object[] {dss.getTaiKhoan(), dss.getTen(), dss.getSDT(), dss.getNgayVL()});
    }
}
    
        public void HienThiDSDoUong(){
            Vector<clssDoUong> ds = new Vector<clssDoUong>();

            int ketqua = DAO.tbDoUong.LayDSDoUong(ds);
            if(ketqua == -1){
                JOptionPane.showMessageDialog(this, "Loi ket noi sql");
                return;
            }
            else if(ketqua == -2){
                JOptionPane.showMessageDialog(this, "Loi sql");
                return;
            }
            else{
                DefaultTableModel dtm = (DefaultTableModel)this.tbDoUong.getModel();
                dtm.setRowCount(0);
                for(clssDoUong dss : ds)
                    dtm.addRow(new Object[] {dss.getID(), dss.getTenDoUong(), dss.getDonGia()});
            }
        }
    
    public void HienThiDSThongKe(){
        Connection conn = DAO.Database.KetNoiCSDL();
        if(conn == null)
        {
            JOptionPane.showMessageDialog(this, "Loi ket noi");
            return;
        }
        String sql = "select Ten, DonGia, sum(SoLuong) as tong, sum(ThanhTien) as thanhtien from thong_ke "
                + " group by Ten, DonGia "
                + " order by tong desc ";
           
        try {
            PreparedStatement stm = conn.prepareStatement(sql);
            ResultSet rs = stm.executeQuery();
            DefaultTableModel dtm = (DefaultTableModel)this.tbThongKe.getModel();
            dtm.setNumRows(0);
            int dem = 0;
            while(rs.next()){
                dem ++;  
                String ten = rs.getString("ten");
                float dongia = rs.getFloat("dongia");
                float thanhtien = rs.getFloat("thanhtien"); 
                int tong = rs.getInt("tong");
                dtm.addRow(new Object[] { ten, Float.toString(dongia), Integer.toString(tong), Float.toString(thanhtien)});
            }
            if(dem == 0){
                JOptionPane.showMessageDialog(this, "Chưa bán được món nào");
            }
        } catch (SQLException ex) {
            Logger.getLogger(frmChonMon.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Loi sql " + ex.getMessage());
            return;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnSuaMonAn = new javax.swing.JButton();
        btnXoaMonAn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMonAn = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnThemDoUong = new javax.swing.JButton();
        btnSuaDoUong = new javax.swing.JButton();
        btnXoaDoUong = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbDoUong = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbThongKe = new javax.swing.JTable();
        btnTongtien = new javax.swing.JButton();
        txtTongTien = new javax.swing.JTextField();
        btnXuat = new javax.swing.JButton();
        btnTaiLaiDS = new javax.swing.JButton();
        btnLamMoiDS = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tbNhanVien = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btnXoaNV = new javax.swing.JButton();
        btnSuaNV = new javax.swing.JButton();
        btnThemNV = new javax.swing.JButton();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        jMenuItem3.setText("jMenuItem3");

        jMenuItem4.setText("jMenuItem4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/delicious_food_hamburger_junk_food_fast_food_burger_icon_258892.png"))); // NOI18N
        jLabel1.setText("MÓN ĂN");

        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Add_27013.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSuaMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/edit_icon_129126.png"))); // NOI18N
        btnSuaMonAn.setText("Sửa");
        btnSuaMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaMonAnActionPerformed(evt);
            }
        });

        btnXoaMonAn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/blue_delete_delete_12491.png"))); // NOI18N
        btnXoaMonAn.setText("Xóa");
        btnXoaMonAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaMonAnActionPerformed(evt);
            }
        });

        tblMonAn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Tên món ăn", "Đơn giá"
            }
        ));
        jScrollPane1.setViewportView(tblMonAn);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSuaMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(btnXoaMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSuaMonAn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaMonAn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Món ăn", jPanel1);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 153, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/water_icon_150091.png"))); // NOI18N
        jLabel2.setText("ĐỒ UỐNG");

        btnThemDoUong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Add_27013.png"))); // NOI18N
        btnThemDoUong.setText("Thêm");
        btnThemDoUong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemDoUongActionPerformed(evt);
            }
        });

        btnSuaDoUong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/edit_icon_129126.png"))); // NOI18N
        btnSuaDoUong.setText("Sửa");
        btnSuaDoUong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaDoUongActionPerformed(evt);
            }
        });

        btnXoaDoUong.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/blue_delete_delete_12491.png"))); // NOI18N
        btnXoaDoUong.setText("Xóa");
        btnXoaDoUong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaDoUongActionPerformed(evt);
            }
        });

        tbDoUong.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Tên đồ uống", "Đơn giá"
            }
        ));
        jScrollPane2.setViewportView(tbDoUong);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(btnThemDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(btnSuaDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(btnXoaDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnThemDoUong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnSuaDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnXoaDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 324, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Đồ uống", jPanel2);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 51, 51));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Danh sách đồ ăn đã bán ngày hôm nay");

        tbThongKe.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tên", "Đơn giá", "Số lượng", "Thành tiền"
            }
        ));
        jScrollPane3.setViewportView(tbThongKe);

        btnTongtien.setBackground(new java.awt.Color(255, 102, 51));
        btnTongtien.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnTongtien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/353403-cart_107514.png"))); // NOI18N
        btnTongtien.setText("Tổng tiền");
        btnTongtien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTongtienActionPerformed(evt);
            }
        });

        txtTongTien.setEditable(false);
        txtTongTien.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N

        btnXuat.setBackground(new java.awt.Color(0, 255, 0));
        btnXuat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/save.png"))); // NOI18N
        btnXuat.setText("Xuất Ra FIle");
        btnXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXuatActionPerformed(evt);
            }
        });

        btnTaiLaiDS.setBackground(new java.awt.Color(204, 0, 204));
        btnTaiLaiDS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Actions-view-refresh-icon.png"))); // NOI18N
        btnTaiLaiDS.setText("Tải lại danh sách");
        btnTaiLaiDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTaiLaiDSActionPerformed(evt);
            }
        });

        btnLamMoiDS.setBackground(new java.awt.Color(0, 153, 153));
        btnLamMoiDS.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnLamMoiDS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Action-cancel-icon.png"))); // NOI18N
        btnLamMoiDS.setText("Xóa toàn bộ danh sách");
        btnLamMoiDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiDSActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(btnTongtien)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnXuat)
                                    .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btnLamMoiDS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnTaiLaiDS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnTongtien)
                            .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnTaiLaiDS, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLamMoiDS, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Thống kê", jPanel3);

        tbNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Tài Khoản", "Tên", "SDT", "Ngày Vào Làm"
            }
        ));
        jScrollPane5.setViewportView(tbNhanVien);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setText("Thông Tin Nhân Viên");

        btnXoaNV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/blue_delete_delete_12491.png"))); // NOI18N
        btnXoaNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaNVActionPerformed(evt);
            }
        });

        btnSuaNV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/edit_icon_129126.png"))); // NOI18N
        btnSuaNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaNVActionPerformed(evt);
            }
        });

        btnThemNV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Add_27013.png"))); // NOI18N
        btnThemNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemNVActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnThemNV, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSuaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnXoaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnThemNV)
                    .addComponent(btnSuaNV)
                    .addComponent(btnXoaNV))
                .addGap(0, 8, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(100, 100, 100))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(84, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Nhân Viên", jPanel4);

        jMenu3.setText("Hệ thống");

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/exit_17886.png"))); // NOI18N
        jMenuItem1.setText("Đăng xuất");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem1);

        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/shut_down.png"))); // NOI18N
        jMenuItem2.setText("Thoát");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem2);

        jMenuBar2.add(jMenu3);

        setJMenuBar(jMenuBar2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(197, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 496, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        frmLuaChonNguoiDung chon = new frmLuaChonNguoiDung();
        chon.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void btnLamMoiDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiDSActionPerformed
        // TODO add your handling code here:
        Connection conn = DAO.Database.KetNoiCSDL();
        if(conn == null)
        {
            JOptionPane.showMessageDialog(this, "Loi ket noi");
            return;
        }
        String sql = "delete from thong_ke ";

        try {
            PreparedStatement stm = conn.prepareStatement(sql);
            int n = stm.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(this, "Làm mới thành công");
            }
        } catch (SQLException ex) {
            Logger.getLogger(frmThanhToan.class.getName()).log(Level.SEVERE, null, ex);
        }

       String sqll = "DBCC CHECKIDENT ('thong_ke', RESEED, 1)";

        try {
            PreparedStatement stm = conn.prepareStatement(sqll);
            stm.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(frmThanhToan.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Lôi sql " + ex.getMessage());
        }

        HienThiDSThongKe();
    }//GEN-LAST:event_btnLamMoiDSActionPerformed

    private void btnTongtienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTongtienActionPerformed
        // TODO add your handling code here:
        DefaultTableModel dtm = (DefaultTableModel)this.tbThongKe.getModel();
        int row = dtm.getRowCount();
        float tongtien = 0f;
        for (int i = 0; i < row; i++) {
            String x = (String)this.tbThongKe.getValueAt(i, 3);
            float xx = Float.parseFloat(x);
            tongtien += xx;
        }
        this.txtTongTien.setText(Float.toString(tongtien));
    }//GEN-LAST:event_btnTongtienActionPerformed

    private void btnXoaDoUongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaDoUongActionPerformed
        // TODO add your handling code here:
        int i = this.tbDoUong.getSelectedRow();
        if(i < 0){
            JOptionPane.showMessageDialog(this, "Chưa chọn món ăn");
            return;
        }
        int hoi = JOptionPane.showConfirmDialog(this, "Chắc chắn xóa ??", "Thông báo !!!", JOptionPane.YES_NO_OPTION);
        if(hoi == JOptionPane.YES_OPTION){
            int id = (int)this.tbDoUong.getValueAt(i, 0);
            int ketqua = DAO.tbDoUong.XoaDoUong(id);
            if(ketqua == -1){
                JOptionPane.showMessageDialog(this, "Loi ket noi sql");
                return;
            }
            else if(ketqua == -2){
                JOptionPane.showMessageDialog(this, "Loi sql");
                return;
            }
            else{
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                HienThiDSDoUong();
            }
        }
    }//GEN-LAST:event_btnXoaDoUongActionPerformed

    private void btnSuaDoUongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaDoUongActionPerformed
        // TODO add your handling code here:
        int i = this.tbDoUong.getSelectedRow();
        if(i < 0){
            JOptionPane.showMessageDialog(this, "Chưa chọn đồ uống");
            return;
        }
        int id = (int)this.tbDoUong.getValueAt(i, 0);
        String tendouong = (String)this.tbDoUong.getValueAt(i, 1);
        float dongia = (float)this.tbDoUong.getValueAt(i, 2);

        clssDoUong douongg = new clssDoUong(id, tendouong, dongia);
        frmSuaDoUong suadouong = new frmSuaDoUong();
        suadouong.douong = douongg;
        suadouong.csdouong = this;
        suadouong.setVisible(true);
    }//GEN-LAST:event_btnSuaDoUongActionPerformed

    private void btnThemDoUongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemDoUongActionPerformed
        // TODO add your handling code here:
        frmThemDoUong them = new frmThemDoUong();
        them.csDoUong = this;
        them.setVisible(true);
    }//GEN-LAST:event_btnThemDoUongActionPerformed

    private void btnXoaMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaMonAnActionPerformed
        // TODO add your handling code here:
        int i = this.tblMonAn.getSelectedRow();
        if(i < 0){
            JOptionPane.showMessageDialog(this, "Chưa chọn món ăn");
            return;
        }
        int hoi = JOptionPane.showConfirmDialog(this, "Chắc chắn xóa ??", "Thông báo !!!", JOptionPane.YES_NO_OPTION);
        if(hoi == JOptionPane.YES_OPTION){
            int id = (int)this.tblMonAn.getValueAt(i, 0);
            int ketqua = DAO.tbMonAn.XoaMonAn(id);
            if(ketqua == -1){
                JOptionPane.showMessageDialog(this, "Loi ket noi sql");
                return;
            }
            else if(ketqua == -2){
                JOptionPane.showMessageDialog(this, "Loi sql");
                return;
            }
            else{
                JOptionPane.showMessageDialog(this, "Xóa thành công");
                HienThiDSMonAn();
            }
        }
    }//GEN-LAST:event_btnXoaMonAnActionPerformed

    private void btnSuaMonAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaMonAnActionPerformed
        // TODO add your handling code here:
        int i = this.tblMonAn.getSelectedRow();
        if(i < 0){
            JOptionPane.showMessageDialog(this, "Chưa chọn món ăn");
            return;
        }
        int id = (int)this.tblMonAn.getValueAt(i, 0);
        String tenmonan = (String)this.tblMonAn.getValueAt(i, 1);
        float dongia = (float)this.tblMonAn.getValueAt(i, 2);

        clssMonAn monann = new clssMonAn(id, tenmonan, dongia);
        frmSuaMonAn suamonan = new frmSuaMonAn();
        suamonan.monan = monann;
        suamonan.csMonAn = this;
        suamonan.setVisible(true);
    }//GEN-LAST:event_btnSuaMonAnActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
        frmThemMonAn them = new frmThemMonAn();
        them.csMonAn = this;
        them.setVisible(true);
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnXuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXuatActionPerformed
        // TODO add your handling code here:
    DefaultTableModel dtm = (DefaultTableModel) this.tbThongKe.getModel();
    int row = dtm.getRowCount();
    float tongTien = 0f;

    // Tạo một workbook mới
    try (Workbook workbook = new XSSFWorkbook()) {
        // Tạo một trang tính mới
        Sheet sheet = workbook.createSheet("ThongKe");

        // Tạo một dòng mới cho tiêu đề "Danh sách đồ ăn bán trong ngày hôm nay"
        Row titleRow = sheet.createRow(0);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("Danh sách đồ ăn bán trong ngày hôm nay");

        // Tạo một CellStyle mới cho tiêu đề
        CellStyle titleStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setColor(IndexedColors.RED.getIndex()); // Đặt màu chữ thành màu đỏ
        titleStyle.setFont(font);
       
        // Áp dụng CellStyle vào ô tiêu đề
        titleCell.setCellStyle(titleStyle);

        // Di chuyển tiêu đề cột xuống dưới
        int startRow = 1;

        // Tạo tiêu đề cho cột
        Row headerRow = sheet.createRow(startRow);
        for (int i = 0; i < dtm.getColumnCount(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(dtm.getColumnName(i));
        }

        // Sao chép dữ liệu từ JTable sang Excel
        for (int i = 0; i < row; i++) {
            Row excelRow = sheet.createRow(i + startRow + 1);
            for (int j = 0; j < dtm.getColumnCount(); j++) {
                String value = String.valueOf(dtm.getValueAt(i, j));
                excelRow.createCell(j).setCellValue(value);
                if (j == 3) { // Cột thứ 4 chứa giá trị tiền
                    tongTien += Float.parseFloat(value);
                }
            }
        }

        // Tạo một ô để hiển thị tổng tiền
        Row totalRow = sheet.createRow(startRow + row + 1);
        Cell totalCell = totalRow.createCell(dtm.getColumnCount() - 1);
        totalCell.setCellValue("Tổng tiền:");
        totalCell = totalRow.createCell(dtm.getColumnCount());
        totalCell.setCellValue(tongTien);

        // Lưu workbook vào một tệp Excel
        try (FileOutputStream outputStream = new FileOutputStream("thongke.xlsx")) {
            workbook.write(outputStream);
        }

        // Thông báo cho người dùng biết rằng việc xuất đã hoàn thành
        JOptionPane.showMessageDialog(this, "Xuất dữ liệu thành công!");
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Đã xảy ra lỗi khi xuất dữ liệu!");
    }
    }//GEN-LAST:event_btnXuatActionPerformed

    private void btnThemNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemNVActionPerformed
        // TODO add your handling code here:
        frmThemNhanVien them = new frmThemNhanVien() ;
        them.csNhanVien = this;
        them.setVisible(true);
    }//GEN-LAST:event_btnThemNVActionPerformed

    private void btnSuaNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaNVActionPerformed
        int selectedRow = tbNhanVien.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Chưa chọn nhân viên");
            return;
        }

        // Retrieve the information of the selected employee
        String taiKhoan = (String) tbNhanVien.getValueAt(selectedRow, 0);
        String ten = (String) tbNhanVien.getValueAt(selectedRow, 1);
        int sdt = (int) tbNhanVien.getValueAt(selectedRow, 2);
        Date ngayVL = (Date) tbNhanVien.getValueAt(selectedRow, 3);

        // Create a new instance of frmSuaNhanVien
        frmSuaNhanVien sua = new frmSuaNhanVien();

        // Set the properties of frmSuaNhanVien
        sua.csNhanVien = this;

        // Khởi tạo đối tượng nhân viên mà không cần mật khẩu
        clssNhanVien nhanvien = new clssNhanVien(taiKhoan, null, ten, sdt, ngayVL);
        sua.nhanvien = nhanvien;

        // Display the form
        sua.setVisible(true);
    }//GEN-LAST:event_btnSuaNVActionPerformed

    private void btnXoaNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaNVActionPerformed
        // TODO add your handling code here:
        int i = this.tbNhanVien.getSelectedRow();
        if (i < 0) {
            JOptionPane.showMessageDialog(this, "Chưa chọn nhân viên");
            return;
        }

        int hoi = JOptionPane.showConfirmDialog(this, "Chắc chắn xóa nhân viên này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
        if (hoi == JOptionPane.YES_OPTION) {
            String taiKhoan = (String) this.tbNhanVien.getValueAt(i, 0); // Lấy tài khoản của nhân viên
            int ketqua = DAO.tbNhanVien.XoaNhanVien(taiKhoan);

            if (ketqua == -1) {
                JOptionPane.showMessageDialog(this, "Lỗi kết nối SQL");
                return;
            } else if (ketqua == -2) {
                JOptionPane.showMessageDialog(this, "Lỗi SQL");
                return;
            } else {
                JOptionPane.showMessageDialog(this, "Xóa nhân viên thành công");
                HienThiNhanVien(); // Hàm này cần được thay thế bằng phương thức hiển thị lại danh sách nhân viên trên giao diện của bạn
            }
        }
    }//GEN-LAST:event_btnXoaNVActionPerformed

    private void btnTaiLaiDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTaiLaiDSActionPerformed
        // TODO add your handling code here:
        HienThiDSThongKe() ;
    }//GEN-LAST:event_btnTaiLaiDSActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmThucDon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmThucDon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmThucDon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmThucDon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmThucDon().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLamMoiDS;
    private javax.swing.JButton btnSuaDoUong;
    private javax.swing.JButton btnSuaMonAn;
    private javax.swing.JButton btnSuaNV;
    private javax.swing.JButton btnTaiLaiDS;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnThemDoUong;
    private javax.swing.JButton btnThemNV;
    private javax.swing.JButton btnTongtien;
    private javax.swing.JButton btnXoaDoUong;
    private javax.swing.JButton btnXoaMonAn;
    private javax.swing.JButton btnXoaNV;
    private javax.swing.JButton btnXuat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tbDoUong;
    private javax.swing.JTable tbNhanVien;
    private javax.swing.JTable tbThongKe;
    private javax.swing.JTable tblMonAn;
    private javax.swing.JTextField txtTongTien;
    // End of variables declaration//GEN-END:variables
}
